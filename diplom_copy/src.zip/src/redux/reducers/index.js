import { LOGIN_USER, LOGOUT_USER, ADD_GOODS,DELETE_GOODS } from "../contstants/action-types";
//import store from "../store/index";
const initialState = {
  user: null,
  isAuthenticated: false,
  shoplist: []
};
function rootReducer(state = initialState, action) {
  console.log('This is reducer');
  console.log(state);
  if (action.type === LOGIN_USER) {
    return Object.assign({}, state, {
      ...state,
      user: action.payload,
      isAuthenticated: true
    });
  }
  if (action.type === LOGOUT_USER) {
    return Object.assign({}, state, {
      ...state,
      user: null,
      isAuthenticated: false
    });
  }
  if (action.type === ADD_GOODS) {
    return {
      ...state,
      shoplist: [...state.shoplist, action.payload]

    };
   }
   
   if (action.type === DELETE_GOODS) {
    const newState = state.shoplist.filter(val => val.uuid !== action.payload.uuid );
    return {
      ...state,
      shoplist: newState

    };
   }


  return state;
}
export default rootReducer;