import React, { Component } from 'react'
import { connect } from "react-redux";
import { uuid4 } from '../util/APIUtils';
import { Table, Button } from 'react-bootstrap';
import { deleteGoodsFromShopList } from "../redux/actions/index";

const mapStateToProps = state => {
    return { shoplist: state.shoplist };
};

function mapDispatchToProps(dispatch) {
    return {
        deleteGoodsFromShopList: item => dispatch(deleteGoodsFromShopList(item)),
    };
}





class ShopListReact extends Component {

    constructor(props) {
        super(props);
        console.log(this.props);
        console.log("This is shop list");
        console.log(this.props);
        console.log(this.props.shoplist);
    }

    handleClick(item) {


        this.props.deleteGoodsFromShopList(item);

    }

    render() {
        return (
            <div>
                <h4>Содержимое корзины</h4>

                <Table striped bordered hover>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Наиненование товара</th>
                            <th>Цена</th>
                            <th>Вес</th>
                            <th>Описание</th>
                            <th>Действие</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.props.shoplist.map((el, index) => (
                            <tr key={el.uuid}>
                                <td>{index + 1}</td>
                                <td>{el.name}</td>
                                <td>{el.price}</td>
                                <td>{el.weight}</td>
                                <td>{el.description}</td>
                                <td><Button onClick={() => { this.handleClick(el) }}  >Удалить</Button></td>
                            </tr>
                        ))}

                    </tbody>
                </Table>
            </div>
        );
    }
}

const ShopList = connect( mapStateToProps,mapDispatchToProps)(ShopListReact);
export default ShopList;