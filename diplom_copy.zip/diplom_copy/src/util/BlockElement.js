import React,{  Component } from 'react';
import './style.css'

class BlockElement extends Component {
  //  constructor(props) {
       // super(props);
       // this.state = {
       //     color: '',
       // }

  //  }

    render() {
        return (
            <div className="blocks">
                <p>Hello</p>
            </div>
        );

    }
}
export default BlockElement;