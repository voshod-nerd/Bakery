import React, { Component } from 'react';
import HeaderEl from '../common/Header';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import BlueBlock from "../user/block/BlueBlock";
import {
    Route,
    withRouter,
    Switch
} from 'react-router-dom';

import AdminPage from '../user/admin/AdminPage';
import AddContentPage from '../adminTools/AddContentPage';
import Login from '../user/login/Login';
import Signup from '../user/signup/Signup';
import NotFound from '../common/NotFound.js';


import Main from '../common/Main';




class AdminPart extends Component {
    constructor(props) {
        super(props);
        this.state = {
            user: null,
            isLoading: false
        }

    }


    render() {
        return (
            <div >
                <HeaderEl isAuthenticated={this.state.isAuthenticated}
                    currentUser={this.state.currentUser}
                    onLogout={this.handleLogout}></HeaderEl>
                <Container>
                    <Row>

                        <Col xs={2}> <BlueBlock currentUser={this.state.currentUser} isLoading={this.state.isLoading} />
                        </Col>
                        <Col>
                            <Switch>
                               
                                <Route exact path="/addcontent"
                                    render={(props) => <AddContentPage  {...props}></AddContentPage>}>
                                </Route>

                                <Route exact path="/admintools"
                                    render={(props) => <AdminPage isAuthenticated={this.state.isAuthenticated} currentUser={this.state.currentUser} {...props}></AdminPage>}>
                                </Route>

                                <Route path="/login"
                                    render={(props) => <Login onLogin={this.handleLogin} {...props} />}></Route>
                                <Route path="/signup" component={Signup}></Route>
                                <Route component={NotFound}></Route>
                            </Switch>


                        </Col>
                        <Col xs={2}><BlueBlock currentUser={this.state.currentUser} isLoading={this.state.isLoading}></BlueBlock></Col>
                    </Row>
                </Container>
            </div>

        );


    }


}

export default withRouter(AdminPart);