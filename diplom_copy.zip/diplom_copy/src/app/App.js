import React, { Component } from 'react';


import {
  Route,
  withRouter,
  Switch
} from 'react-router-dom';

import { getCurrentUser } from '../util/APIUtils';
import { ACCESS_TOKEN } from '../constants';

//import Login from '../user/login/Login';
//import Signup from '../user/signup/Signup';
//import NotFound from '../common/NotFound.js';

//import Container from 'react-bootstrap/Container';
//import Row from 'react-bootstrap/Row';
//import Col from 'react-bootstrap/Col';
//import HeaderEl from '../common/Header';
//import MainPage from '../common/MainPage';
//import BlueBlock from "../user/block/BlueBlock";

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.min.css';
//import AdminPage from '../user/admin/AdminPage';
//import AddContentPage from '../adminTools/AddContentPage';
///import AdminPart from './AdminPart';
import { loginUser, logOutUser } from "../redux/actions/index";
import MainHeader from "../common/MainHeader/MainHeader";
import Main from "../common/Main/Main";
import Login from "../user/login/Login";

import Signup from '../user/signup/Signup';
import { connect } from "react-redux";
import { Container } from 'react-bootstrap';
function mapDispatchToProps(dispatch) {
  return {
    loginUser: user => dispatch(loginUser(user)),
    logOutUser: user => dispatch(logOutUser(user))
  };
}


class Apps extends Component {


  constructor(props) {
    super(props);
    this.state = {
      currentUser: null,
      isAuthenticated: false,
      isLoading: false
    }
    this.handleLogout = this.handleLogout.bind(this);
    this.loadCurrentUser = this.loadCurrentUser.bind(this);
    this.handleLogin = this.handleLogin.bind(this);
  }


  loadCurrentUser() {
    this.setState({
      isLoading: true
    });
    getCurrentUser()
      .then(response => {
        this.props.loginUser(response);
        let role = response.roles[0];
        console.log(role);
        switch (role) {
          case "ROLE_USER": this.props.history.push("/"); break;
          case "ROLE_ADMIN": this.props.history.push("/admin"); break;
          case "ROLE_DRIVER": this.props.history.push("/driver"); break;
          default: break;
        }
        console.log("I here");
        console.log(response);
        //this.props.history.push("/"); 

        this.setState({
          currentUser: response,
          isAuthenticated: true,
          isLoading: false
        });
        console.log(response);
      }).catch(error => {
        this.setState({
          isLoading: false
        });
      });
  }


  handleLogout(redirectTo = "/", notificationType = "success", description = "You're successfully logged out.") {
    localStorage.removeItem(ACCESS_TOKEN);

    console.log('handleLogout');
    this.props.logOutUser({ user: null, isAuthenticated: false });
    /*this.setState({
      currentUser: null,
      isAuthenticated: false
    });
    */

    this.props.history.push(redirectTo);

    toast.info('Вы вышли из учетной записи', {
      position: "top-center",
      autoClose: false,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      type: 'error'
    });
  }
  handleLogin() {
    toast.info('Вы успешно авторизовались', {
      position: "top-center",
      autoClose: false,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      type: 'error'
    });
    console.log('This is login');
    this.loadCurrentUser();
    this.props.history.push("/");

  }

  componentDidMount() {

    this.loadCurrentUser();
  }

  render() {
    return (
      <div >
        <ToastContainer rtl />
        <MainHeader onLogout={this.handleLogout} />
        <Container>
          <Switch>
            <Route exact path="/"
              render={(props) => <Main  {...props}></Main>}>
            </Route>
            <Route path="/login"

              render={(props) => <Login onLogin={this.handleLogin} {...props} />}></Route>
            <Route path="/signup" component={Signup}></Route>
            <Main />
          </Switch>
        </Container>
      </div>
    );
  }
}

const App = withRouter(Apps);
export default connect(null, mapDispatchToProps)(App);
